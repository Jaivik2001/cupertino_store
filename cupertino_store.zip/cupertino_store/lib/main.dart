import 'package:flutter/material.dart';

import 'Screen/homescreen.dart';

void main() {
  runApp( const MaterialApp(home: HomePage(),));
}
